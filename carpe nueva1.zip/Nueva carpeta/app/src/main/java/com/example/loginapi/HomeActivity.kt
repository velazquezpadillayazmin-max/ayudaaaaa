package com.example.loginapi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ERROR CORREGIDO: Debe ser activity_home (tu diseño de bienvenida)
        setContentView(R.layout.activity_login)

        val tvName: TextView = findViewById(R.id.tvName)
        val btnLogout: Button = findViewById(R.id.btnLogout)

        // Recibimos el nombre (ej. "fer")
        val nombreUsuario = intent.getStringExtra("USER_NAME")
        tvName.text = "¡Hola, ${nombreUsuario ?: "Usuario"}!"

        btnLogout.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Cierra HomeActivity para no volver atrás al presionar retroceder
        }
    }
}
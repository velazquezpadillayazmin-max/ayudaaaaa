package com.example.loginapi

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etusuario: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etusuario = findViewById(R.id.etUsuario)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val usuario = etusuario.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (validarDatos(usuario, password)) {
                // Tu lógica de validación
                if (usuario == "fernanda" && password == "123") {
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.putExtra("USER_NAME", usuario)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun validarDatos(u: String, p: String): Boolean {
        if (u.isEmpty()) {
            etusuario.error = "Ingresa tu usuario"
            return false
        }
        if (p.isEmpty()) {
            etPassword.error = "Ingresa tu contraseña"
            return false
        }
        return true
    }
}
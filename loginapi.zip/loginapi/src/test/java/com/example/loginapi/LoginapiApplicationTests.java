package com.example.loginapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

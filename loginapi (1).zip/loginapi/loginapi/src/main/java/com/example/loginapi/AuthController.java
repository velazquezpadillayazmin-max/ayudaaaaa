package com.example.loginapi; // <--- IMPORTANTE: Ahora coincide con la carpeta

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

// 1. Clase para recibir los datos (Puede ir aquí mismo sin 'public')
class LoginRequest {
    public String usuario;
    public String password;
}

// 2. El Controlador
@RestController
@CrossOrigin(origins = "*") // Permite que Android se conecte
public class AuthController {

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody LoginRequest request) {
        Map<String, Object> response = new HashMap<>();

        System.out.println("Intento de login: " + request.usuario);

        // Validación
        if ("Juan Diego".equals(request.usuario) && "Juan Diego2006".equals(request.password)) {
            response.put("success", true);
            response.put("message", "¡Bienvenido, Juan Diego (API en ejecución)!");
        } else {
            response.put("success", false);
            response.put("message", "Usuario o contraseña incorrectos");
        }
        return response;
    }
}